import pandas
import datetime
import count

class Pandacomptelog():
    """Représente une gestion de comptes avec Panda.

    Cette classe permet de lire et écrire des données de compte à partir d'un fichier CSV, 
    ajouter et supprimer des comptes, et récupérer et modifier le solde d'un compte.

    Attributes:
        basepanda: La base des comptes.

    Methods:
        __init__(self, fichier): Initialise l'objet PandaCompteLog en lisant les données du fichier CSV spécifié.
        sauvegarder_dans_csv(self, fichier): Sauvegarde l'état actuel de la base de données dans un fichier CSV.
        __str__(self): Retourne une représentation sous forme de chaîne de la base de données.
        ajouter_un_compte_dans_panda(self, account): Ajoute un compte à la base de données.
        recupere_compte_panda(self, numero_de_compte): Récupère un compte de la base de données.
        supprimer_un_compte_dans_panda(self, numero_de_compte): Supprime un compte de la base de données.
        modifier_solde_compte(self, compte): Modifie le solde d'un compte dans la base de données.
    """

    def __init__(self, fichier):
        """Créé un nouvel objet PandaCompteLog.

        Args:
            fichier (str): Le chemin du fichier CSV à utiliser.
        """
        self.basepanda = pandas.read_csv(fichier, na_filter=False)

    def sauvegarder_dans_csv(self, fichier):
        """Sauvegarde la base de données PandaCompte dans un fichier CSV.

        Args:
            fichier (str): Le chemin du fichier CSV de sauvegarde.
        """
        self.basepanda.to_csv(fichier, index=False)

    def __str__(self):
        """Retourne PandaCompte sous forme de string"""
        return str(self.basepanda)

    def ajouter_un_compte_dans_panda(self, account):
        """Ajoute un compte à la base de données PandaCompte.

        Args:
            account (count.Account): Le compte à ajouter.
        """
        date = datetime.datetime.now().strftime("%d/%m/%y")
        heure = datetime.datetime.now().strftime("%H:%M:%S")
        if account.get_account_type() == "C":
            frame_tempo = pandas.DataFrame({"Date": [date], "Heure": [heure], "Compte": [account.get_account_nb()],
                                            "Type": [account.get_account_type()], "Taux" : [""],
                                            "Solde": [account.get_account_balance()]})
        else:
            frame_tempo = pandas.DataFrame({"Date": [date], "Heure": [heure], "Compte": [account.get_account_nb()],
                                            "Type": [account.get_account_type()], "Taux": [account.get_account_rate()],
                                            "Solde": [account.get_account_balance()]})
        self.basepanda = pandas.concat([self.basepanda, frame_tempo], ignore_index=True)

    def recupere_compte_panda(self, numero_de_compte):
        """Récupère un compte de la base PandaCompte.

        Args:
            numero_de_compte (str): Le numéro de compte à récupérer.

        Returns:
            count.Account: Le compte récupéré.
        """
        type_du_compte = self.basepanda.loc[self.basepanda['Compte'] == numero_de_compte, 'Type'].item()
        valeur_du_compte = float(self.basepanda.loc[self.basepanda['Compte'] == numero_de_compte, 'Solde'].item())
        if type_du_compte == "C":
            compte = count.Account(numero_de_compte, type_du_compte, valeur_du_compte)
        else:
            taux_du_compte = float(self.basepanda.loc[self.basepanda['Compte'] == numero_de_compte, 'Taux'].item())
            compte = count.InterestAccount(numero_de_compte, type_du_compte, valeur_du_compte, taux_du_compte)
        return compte

    def supprimer_un_compte_dans_panda(self, numero_de_compte):
        """Supprime un compte de la base PandaCompte.csv


        Args:
            numero_de_compte (str): Le numéro de compte à supprimer.
        """
        index_ligne_a_suppr = self.basepanda[self.basepanda['Compte'] == numero_de_compte].index.item()
        self.basepanda.drop(index_ligne_a_suppr, inplace=True)
        self.basepanda.reset_index(drop=True, inplace=True)

    def modifier_solde_compte(self, compte):
        """Modifie le solde d'un compte dans la base PandaCompte.

        Args:
            compte (count.Account): Le compte dont le solde doit être modifié.
        """
        solde = compte.get_account_balance()
        numero_de_compte = compte.get_account_nb()
        self.basepanda.loc[self.basepanda['Compte'] == numero_de_compte, 'Solde'] = solde



