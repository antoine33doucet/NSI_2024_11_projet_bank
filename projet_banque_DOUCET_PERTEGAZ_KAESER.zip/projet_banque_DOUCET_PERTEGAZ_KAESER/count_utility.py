def verifier_existance_compte(numero_de_compte, panda_compte):
    """Vérifie l'existence d'un compte en utilisant la méthode PandaCompte.

    Args:
        numero_de_compte (str): Le numéro de compte à vérifier.
        panda_compte (PandaCompte): l'objet panda_compte.

    Returns:
        bool: True si le compte existe, False sinon.
    """
    try:
        panda_compte.recupere_compte_panda(numero_de_compte)
        return True
    except Exception:
        return False