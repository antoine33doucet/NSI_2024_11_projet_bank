import count
import count_utility
import exception


def afficher_aide():
    """
    Affiche un menu d'aide permettant à l'utilisateur de choisir parmi différentes options :
    1. Créer un compte
    2. Afficher un compte
    3. Afficher un compte
    4. Créer une ligne comptable
    5. Afficher tous les comptes
    6. Afficher toutes les opérations
    """
    print("""
        Vous avez besoin d'aide pour ?
        ╔════════════════════════════════════════╗
        ║ 1. Creer un compte                     ║
        ║ 2. Supprimer un compte                 ║
        ║ 3. Afficher un compte                  ║
        ║ 4. Créer une ligne comptable           ║
        ║ 5. Afficher tous les comptes           ║
        ║ 6. Afficher toutes les opérations      ║
        ║ 7. Quitter                             ║
        ╚════════════════════════════════════════╝""")
    while True :
        try :
            help_choix = int(input("Sélectionner l'option dont vous avez besoin de 1 à 7 : "))
            if help_choix > 0 and help_choix < 8:
                break
            else :
                raise ValueError()
        except:
            print("Votre choix n'est pas un chiffre ou n'est pas compris entre 1 et 7")

    if help_choix == 1:
        print("""
              Pour créer un compte : 

              Il faudra choisir le type du compte.
              C pour un compe courant et E pour un compte épargne. 
              Si vous choisissez un compte épargne il faudra indiquer un taux de placement. 

              Le nom du compte devra commencer par 'FR' puis un numéro. 
              Ensuite mettre la valeur souhaité dans le compte.
              """)
        
    elif help_choix == 2:
        print("""
              Pour supprimer un compte : 

              Il faudra choisir le numéro de compte..
              Le nom du compte devra commencer par 'FR' puis un numéro. 
              """)

    elif help_choix == 3:
        print("""
              Pour afficher un compte: 

              Il faudra indiquer le nom du compte. 
              Le compte commence par 'FR' puis un numéro. 
              """)
        
    elif help_choix == 4:
        print( """
              Pour gérer le compte : 
              
              Il faudra indiquer le nom du compte. 
              Ensuite il faudra choisir si vous vouler effectuer un dépot, un retrait ou un transfert. 
              Pour le dépot vous indiquerez le montant voulu a mettre dans le compte. 
              Pour effectuer un retrait ou un transfert il faudra aussi ajouter le montant voulu 
              mais s'il est supérieur à celui du compte alors vous ne pourrez pas effectuer l'opération.
              """)
        
    elif help_choix == 5:
        print("""
              Pour afficher tout les comptes il faudra sélectionner l'option '7' et les comptes s'afficheront. 
              Toutes les données des comptes seront affichées
              """)
        
    elif help_choix == 6:
        print("Pour afficher toutes les opétations il faudra sélectionner l'option '8' et toutes les opérations seront montrées.")
    
def is_float(string):
    """
    Vérifie si la chaîne de caractères peut être convertie en nombre à virgule.

    Args:
    - string (str): Chaîne de caractères à vérifier.

    Returns:
    - bool: True si la conversion est possible, False sinon.
    """
    try :
        float(string)
        return True
    except ValueError :
        return False


def cree_un_compte(panda_compte):
    """
    Permet à l'utilisateur de créer un nouveau compte en spécifiant le type de compte, le numéro de compte,
    la valeur initiale, et éventuellement le taux de placement pour les comptes épargne.

    Args:
    - panda_compte (objet): Objet contenant les comptes.
    - panda_transaction (objet): Objet contenant les transactions.

    Returns:
    - None
    """
    while True :
        type_de_compte=input("Type du compte [Types possibles : C(ourant) , E(pargne)] : ")
        #numéro de compte
        numero_de_compte=input("Numéro du compte : ")
        #premier dépôt
        str_valeur_initiale=input("Première valeur créditée : ")
        if type_de_compte=="E":
            #taux de placement
            str_taux=input("Taux de placement : ")
        else:
            str_taux = "0.0"
        if type_de_compte == "quitter" or numero_de_compte == "quitter" or str_valeur_initiale == "quitter" or str_taux == "quitter":
            print("annulation de votre demande")
            return
        try:

            assert is_float(str_taux),"Taux de placement doit être un nombre à virgule"
            assert is_float(str_valeur_initiale),"Première valeur créditée doit être un nombre à virgule"
            assert type_de_compte=="C" or type_de_compte=="E", "type de compte inexistant"
            assert numero_de_compte[:2] == "FR", "le compte ne commence pas par FR"
            assert float(str_taux)>=0.0 and float(str_taux)<=100.0, "le taux doit être un nombre à virgule compris entre 0 et 100"
            assert count_utility.verifier_existance_compte(numero_de_compte,panda_compte) == False, "le compte existe déja"
            valeur_initiale = float(str_valeur_initiale)
            assert valeur_initiale <= 250000000000.0, "Vous ne pouvez pas encore être l'Homme le plus riche du monde (patience) "
            assert 0 < valeur_initiale , "Vous ne pouvez avoir un solde négatif sur votre compte"
            taux = float(str_taux)
            
            if type_de_compte=="C":
                compte_en_cours = count.Account(numero_de_compte,type_de_compte,valeur_initiale)
            else:
                compte_en_cours = count.InterestAccount(numero_de_compte,type_de_compte,valeur_initiale,taux)
            break
        except AssertionError as error:
            print("=> Impossible d'effectuer l'action:", error) 

    print("Le compte numéro : " +str(numero_de_compte)+", de type "+str(type_de_compte)+" a été créé. Le solde est de : "+ str(valeur_initiale))
    panda_compte.ajouter_un_compte_dans_panda(compte_en_cours)
    
def supprimer_un_compte(panda_compte):
    """
    Permet à l'utilisateur de supprimer un compte en spécifiant le numéro du compte.
    Args:
    - panda_compte (objet): Objet contenant les comptes.

    Returns:
    - None
    """
    while True :
        le_compte_a_supprimer = input(" Quel compte souhaitez vous supprimer ? ")
        if count_utility.verifier_existance_compte(le_compte_a_supprimer,panda_compte) == True :
            panda_compte.supprimer_un_compte_dans_panda(le_compte_a_supprimer)
            print("Votre compte a été supprimé avec succès")
            break
        elif le_compte_a_supprimer == "quitter":
            print("annulation de votre demande")
            break
        else :
            print("=> Le compte n'existe pas !!")




def afficher_un_compte(panda_compte):
    """
    Affiche les détails d'un compte spécifié par l'utilisateur.

    Args:
    - panda_compte (objet): Objet contenant les comptes.

    Returns:
    - None
    """
    while True :
        le_compte_a_afficher = input(" Quel compte souhaitez vous afficher ? ")
        if count_utility.verifier_existance_compte(le_compte_a_afficher,panda_compte) == True :
            break
        elif le_compte_a_afficher == "quitter":
            print("annulation de votre demande")
            return
        else :
            print("=> Le compte n'existe pas !!")

    le_compte = panda_compte.recupere_compte_panda(le_compte_a_afficher)
    print("Le compte n° : " +str(le_compte_a_afficher)+" est un compte " + str(le_compte.get_account_type()) )
    if le_compte.get_account_type() == "E":
        print("dont le taux est de " +str(le_compte.get_account_rate()) + "%")
    print("Valeur actuelle : "+ str(le_compte.get_account_balance()))


def cree_une_ligne_comptable(panda_compte,panda_transaction):
    """
    Permet à l'utilisateur d'effectuer des opérations comptables telles que les dépôts, les retraits ou les transferts
    sur un compte spécifié.

    Args:
    - panda_compte (objet): Objet contenant les comptes.
    - panda_transaction (objet): Objet contenant les transactions.

    Returns:
    - None
    """
    while True :
        numero_de_compte =input("Sur quel compte souhaitez-vous intervenir ? : ")
        if numero_de_compte == "quitter":
            print("annulation de votre demande")
            return
        if count_utility.verifier_existance_compte(numero_de_compte,panda_compte) == True :
            break
        else :
            print("=> Le compte n'existe pas !!")

    print("Choisir la nature de l'opération :")
    print(" 1.Pour effectuer un dépôt")
    print(" 2.Pour effectuer un retrait")
    print(" 3.Pour effectuer un transfert")
    print(" 4.Quitter")
    while True :
        try :
            operation = int(input("Votre choix de 1 à 4 : "))
            if operation > 0 and operation < 5 :
                break
            else :
                raise ValueError()
        except:
            print("=> Votre choix n'est pas un chiffre ou n'est pas compris entre 1 et 4")

    mon_compte = panda_compte.recupere_compte_panda(numero_de_compte)

    if operation==1:
        while True :
            try :
                str_depot = float(input("Votre dépôt ? "))
                if str_depot == "quitter":
                    print("Annulation de votre demande")
                    return
                depot = float(str_depot)
                assert depot >=0
                break
            except:
                print("=> Votre valeur de dépôt n'est pas un nombre positif")
        effectuer_un_depot(mon_compte,panda_compte,panda_transaction,depot)

    if operation==2:
        while True :
            try :
                str_retrait = input("Votre retrait ? ")
                if str_retrait == "quitter":
                    print("Annulation de votre demande")
                    return False
                retrait = float(str_retrait)
                assert retrait >=0
                break
            except:
                print("=> Votre valeur de retrait n'est pas un nombre positif")
        effectuer_un_retrait(mon_compte,panda_compte,panda_transaction,retrait)

    if operation==3:
        while True :
            numero_de_compte_tr =input("Vers quel compte souhaitez-vous réaliser un transfert ? : ")
            if numero_de_compte_tr == "quitter":
                print("Annulation de votre demande")
                return
            elif count_utility.verifier_existance_compte(numero_de_compte_tr,panda_compte) == True :
                break
            else :
                print("=> Le compte n'existe pas !!")
        compte_tr = panda_compte.recupere_compte_panda(numero_de_compte_tr)
        while True :
            try :
                str_tranfere = input("Valeur du transfert ? : ")
                if str_tranfere == "quitter":
                    print("Annulation de votre demande")
                    return 
                tranfere = float(str_tranfere)
                assert tranfere >=0
                break
            except:
                print("Votre valeur de transfert n'est pas un nombre positif")
        tranfere_argent(mon_compte,panda_compte,panda_transaction,tranfere,compte_tr)
    if operation== 4:
        print("Annulation de votre demande")
        return 
    return False

def effectuer_un_depot(mon_compte,panda_compte,panda_transaction,depot,transfère = False):
    """
    Effectue un dépôt sur le compte spécifié.

    Args:
    - mon_compte (objet): Compte sur lequel effectuer le dépôt.
    - panda_compte (objet): Objet contenant les comptes.
    - panda_transaction (objet): Objet contenant les transactions.
    - depot (float): Montant du dépôt.
    - transfere (bool): True si le dépôt est effectué dans le cadre d'un transfert, False sinon.

    Returns:
    - bool: True si le dépôt est réussi, False sinon.
    """
    solde_avant_depot = mon_compte.get_account_balance()
    mon_compte.ajouter_argent(depot)
    if mon_compte.get_account_balance() > 250000000000:
        mon_compte.set_new_solde(solde_avant_depot)
        print("Vous ne pouvez pas encore être l'Homme le plus riche du monde (patience)")
        return False
    panda_compte.modifier_solde_compte(mon_compte)
    numero_de_compte = mon_compte.get_account_nb()
    nouvelle_somme = mon_compte.get_account_balance()
    if transfère == False :
        panda_transaction.ajouter_une_transaction_dans_panda(numero_de_compte,"Crédit",depot,nouvelle_somme)
        print("Dépôt réalisé, le compte", numero_de_compte, "a pour solde", nouvelle_somme)
    else :
        panda_transaction.ajouter_une_transaction_dans_panda(numero_de_compte,"T_Crédit",depot,nouvelle_somme)
    return True

def effectuer_un_retrait(mon_compte,panda_compte,panda_transaction,retrait,transfère = False):
    """
    Effectue un retrait sur le compte spécifié, en vérifiant si le solde ne devient pas négatif.

    Args:
    - mon_compte (objet): Compte sur lequel effectuer le retrait.
    - panda_compte (objet): Objet contenant les comptes.
    - panda_transaction (objet): Objet contenant les transactions.
    - retrait (float): Montant du retrait.
    - transfere (bool): True si le retrait est effectué dans le cadre d'un transfert, False sinon.

    Returns:
    - bool: True si le retrait est réussi, False sinon.
    """
    solde_avant_retrait = mon_compte.get_account_balance()
    try :
        mon_compte.retirer_argent(retrait)
        if mon_compte.get_account_balance() < 0.0:
            raise exception.BalanceException(panda_compte,mon_compte,solde_avant_retrait)
    except exception.BalanceException as error :
        print(error)
        return False

    else :
        panda_compte.modifier_solde_compte(mon_compte)
        numero_de_compte = mon_compte.get_account_nb()
        nouvelle_somme = mon_compte.get_account_balance()
        if transfère == False :
            panda_transaction.ajouter_une_transaction_dans_panda(numero_de_compte,"Débit",retrait,nouvelle_somme)
            print("Retrait réalisé, le compte", numero_de_compte, "a pour solde", nouvelle_somme)
    return True

def tranfere_argent(mon_compte,panda_compte,panda_transaction,tranfere,compte_tr):
    """
    Effectue un transfert d'argent entre deux comptes.

    Args:
    - mon_compte (objet): Compte source du transfert.
    - panda_compte (objet): Objet contenant les comptes.
    - panda_transaction (objet): Objet contenant les transactions.
    - tranfere (float): Montant du transfert.
    - compte_tr (objet): Compte destination du transfert.

    Returns:
    - None
    """
    print("Commencer le transfert")
    try: 
        solde_mon_compte_avant_retrait = mon_compte.get_account_balance()
        if effectuer_un_retrait(mon_compte,panda_compte,panda_transaction,tranfere,True) == False:
            raise exception.BalanceException(panda_compte,mon_compte,solde_mon_compte_avant_retrait)
        if effectuer_un_depot(compte_tr,panda_compte,panda_transaction,tranfere,True) == False:
            raise exception.BalanceException(panda_compte,mon_compte,solde_mon_compte_avant_retrait)
    except exception.BalanceException :
        print("Transfert impossible ❌​")
        return False
    #l'écriture comptable du retrait ne peux être effectué qu'une fois que l'on est sur que le depot est effectif.
    panda_transaction.ajouter_une_transaction_dans_panda(mon_compte.get_account_nb(),"T_Débit",tranfere,mon_compte.get_account_balance())
    print("Transfert réalisé 🚀")
    print("Le compte ", mon_compte.get_account_nb(), " a maintenant pour solde " + str(mon_compte.get_account_balance()))
    print("Le compte ", compte_tr.get_account_nb(), " a maintenant pour solde " + str(compte_tr.get_account_balance()))


def afficher_compte(panda_compte):
    """
    Affiche la liste de tous les comptes disponibles.

    Args:
    - panda_compte (objet): Objet contenant les comptes.

    Returns:
    - None
    """
    print("Voici la liste des comptes : ")
    print(panda_compte)

def afficher_transaction(panda_transaction):
    """
    Affiche la liste de toutes les transactions effectuées.

    Args:
    - panda_transaction (objet): Objet contenant les transactions.

    Returns:
    - None
    """
    print("Voici la liste des transactions : ")
    print(panda_transaction)

