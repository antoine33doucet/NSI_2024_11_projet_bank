import pandas
import datetime
import logbooks

class Pandatransactionlog(logbooks.Pandacomptelog) :
    '''
    Classe représentant un journal de transactions pour la gestion des opérations bancaires.

    Attributes:
    - fichier (str): Le nom du fichier associé au journal de transactions.

    Methods:
    - __init__(self, fichier): Crée un objet Pandatransactionlog en héritant de Pandacomptelog.
    - ajouter_une_transaction_dans_panda(self, numero_de_compte, type_transfere, Valeur, nouvelle_somme): Ajoute une nouvelle
      transaction au journal avec les arguments fournis.

    Returns:
    - None
    '''
    
    def __init__(self,fichier) :
        """Crée un nouvel objet PandaCompteTransaction.

        Args:
            fichier (str): Le chemin du fichier CSV à utiliser.
        """
        super().__init__(fichier)

    
    def ajouter_une_transaction_dans_panda(self,numero_de_compte,type_transfère,Valeur,nouvelle_somme):
        """Ajoute une transaction à Pandatransactionlog.

        Args:
            numero_de_compte (str): Le numéro de compte associé à la transaction.
            type_transfere (str): La nature de la transaction.
            valeur (float): La valeur associée à la transaction.
            nouvelle_somme (float): Le nouveau solde du compte après la transaction.
        """
        date = datetime.datetime.now().strftime("%d/%m/%y")
        heure = datetime.datetime.now().strftime("%H:%M:%S")
        FRAMEtempo = pandas.DataFrame({"Date":[date],"Heure":[heure],"Compte":[numero_de_compte],"Nature":[type_transfère],"Valeur":[Valeur],"Solde":[nouvelle_somme]}) 
        self.basepanda = pandas.concat([self.basepanda,FRAMEtempo],ignore_index=True)

