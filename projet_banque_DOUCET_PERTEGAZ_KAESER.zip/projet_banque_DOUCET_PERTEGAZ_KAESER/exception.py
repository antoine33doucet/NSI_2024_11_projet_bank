class BalanceException(Exception):
    ''' Un objet BalanceException héritant de la classe prédéfinie Exception
    On lèvera une erreur en cas de problème de solde sur le compte

    Attributes:
    - compte_retrait (objet): Le compte sur lequel le retrait a échoué.
    - solde_avant_trans (float): Le solde du compte avant la tentative de retrait.

    Methods:
    - Initialise l'objet BalanceException en mettant à jour le solde du compte avant le retrait et crée un message d'erreur spécifique.

    Returns:
    - None
    '''

    def __init__(self,panda_compte,compte_retrait,solde_avant_retrait):
        compte_retrait.set_new_solde(solde_avant_retrait)
        self.message = f"Retrait impossible, le compte {compte_retrait.get_account_nb()} a pour solde {compte_retrait.get_account_balance()}"
        panda_compte.modifier_solde_compte(compte_retrait)
        super().__init__(self.message)




    
