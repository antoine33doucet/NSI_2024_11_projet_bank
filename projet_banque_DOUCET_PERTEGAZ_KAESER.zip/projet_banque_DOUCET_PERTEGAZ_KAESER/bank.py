__author__ = "three developers" 
__authors__ = ["Antoine DOUCET", "EVAN PERTEGAZ","LUCAS KAESER"]
__copyright__ = "Copyright 2023, Antoine/Evan/Lucas and co"
__credits__ = ["Antoine DOUCET", "EVAN PERTEGAZ","LUCAS KAESER"] 
__date__ = "18/11/2023" 
__email__ =  ""
__license__ = "CC-by-nc-nd"
__maintainer__ = "developer" 
__status__ = "Production" 
__version__ = "1.0.0"

"""

Validé :
Python '3.10.11 (tags/v3.10.11:7d4cc5a, Apr  5 2023, 00:38:17) [MSC v.1929 64 bit (AMD64)]'
Modules natifs :
datetime

Modules externes :
pandas

Modules internes :
choice.py
constant.py
count_utility.py
count.py
exception.py
logbanking.py
logbooks.py


"""
import choice
import logbanking
import logbooks
import constant

def main():
    """
    Fonction principale du programme de gestion de comptes bancaires.

    Crée les objets nécessaires pour la gestion des comptes et des transactions,
    puis affiche un menu principal permettant à l'utilisateur d'effectuer différentes actions.

    Actions disponibles dans le menu :
    1. Créer un compte
    2. Afficher un compte
    3. Créer une ligne comptable
    4. Sortir
    5. Obtenir de l'aide
    6. Afficher tous les comptes
    7. Afficher toutes les opérations

    Returns:
    - None
    """
    panda_transaction = logbanking.Pandatransactionlog(constant.FILENAME_TRANSACTION)
    panda_compte = logbooks.Pandacomptelog(constant.FILENAME_ACCOUNT)

    choix = None
    while choix != 5 :
        print("""
            ╔══════════ Menu principal ═══════════════╗
            ║ 1. Creer un compte                      ║
            ║ 2. Supprimer un compte                  ║
            ║ 3. Afficher un compte                   ║
            ║ 4. Créer une ligne comptable            ║
            ║ 5. Sortir                               ║
            ║ 6. De l'aide                            ║
            ║ 7. Afficher tous les comptes            ║
            ║ 8. Afficher toutes les opérations       ║
            ║  Astuce: à tout moment taper [quitter]  ║
            ║  pour abandonner l'opération en cours   ║
            ╚═════════════════════════════════════════╝
            """)
        while True :
            try :
                choix = int(input("Votre choix de 1 à 8 : "))
                if choix > 0 and choix < 9 :
                    break
                else :
                    raise ValueError()
            except:
                print("Votre choix n'est pas un chiffre ou n'est pas compris entre 1 et 8")
        if choix == 1 :
            choice.cree_un_compte(panda_compte)
            panda_compte.sauvegarder_dans_csv(constant.FILENAME_ACCOUNT)
            input("*** Press any key to continue ! :) ")
        elif choix == 2 :
            choice.supprimer_un_compte(panda_compte)
            panda_compte.sauvegarder_dans_csv(constant.FILENAME_ACCOUNT)
            input("*** Press any key to continue ! :) *** ")
        elif choix == 3 :
            choice.afficher_un_compte(panda_compte)
            input("*** Press any key to continue ! :) *** ")
        elif choix == 4 :
            choice.cree_une_ligne_comptable(panda_compte,panda_transaction)
            panda_compte.sauvegarder_dans_csv(constant.FILENAME_ACCOUNT)
            panda_transaction.sauvegarder_dans_csv(constant.FILENAME_TRANSACTION)
            input("*** Press any key to continue ! :) *** ")
        elif choix == 6 :
            choice.afficher_aide()
            input("*** Press any key to continue ! :) *** ")
        elif choix == 7 :
            choice.afficher_compte(panda_compte)
            input("*** Press any key to continue ! :) *** ")
        elif choix == 8 :
            choice.afficher_transaction(panda_transaction)
            input("*** Press any key to continue ! :) *** ")

if __name__ == "__main__":
    main()
