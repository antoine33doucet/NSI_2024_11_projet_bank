class Account():
    """
    Une classe pour gérer un compte bancaire.


    Attributs
    ----------
    __account_nb (str):  une chaîne de caractères formatée pour représenter le numéro de compte
    __account_type (str): une chaîne de caractères pour représenter le type de compte
    __account_balance (float): un nombre à virgule flottante pour représenter le solde du compte

    Méthodes
    -------
    ajouter_argent(somme): Ajoute une somme d'argent au solde du compte.
    retirer_argent(somme): Retire une somme d'argent du solde du compte.
    get_account_nb():      Renvoie le numéro de compte.
    get_account_type():    Renvoie le type de compte.
    get_account_balance():  Renvoie le solde du compte.
    set_new_solde(new_solde):  Définit un nouveau solde pour le compte.
    """    

    def __init__(self, numero_de_compte, type_de_compte, valeur_initiale):
        """Initialise la classe Account.

        Args:
            numero_de_compte (str): Le numéro de compte.
            type_de_compte (str): Le type de compte.
            valeur_initiale (float): La valeur initiale du solde du compte.
        """
        self.__account_nb = numero_de_compte
        self.__account_type = type_de_compte
        self.__account_balance = valeur_initiale

    def ajouter_argent(self, somme):
        """Ajoute une somme d'argent au solde du compte.

        Args:
            somme (float): La somme d'argent à ajouter.
        """
        self.__account_balance = self.__account_balance + somme

    def retirer_argent(self, somme):
        """Retire une somme d'argent du solde du compte.

        Args:
            somme (float): La somme d'argent à retirer.
        """
        self.__account_balance = self.__account_balance - somme

    def get_account_nb(self):
        """Renvoie le numéro de compte.

        Returns:
            str: Le numéro de compte.
        """
        return self.__account_nb

    def get_account_type(self):
        """Renvoie le type de compte.

        Returns:
            str: Le type de compte.
        """
        return self.__account_type

    def get_account_balance(self):
        """Renvoie le solde du compte.

        Returns:
            float: Le solde du compte.
        """
        return self.__account_balance

    def set_new_solde(self, new_solde):
        """Définit un nouveau solde pour le compte.

        Args:
            new_solde (float): Le nouveau solde à définir.
        """
        self.__account_balance = new_solde


class InterestAccount(Account):
    def __init__(self, numero_de_compte, type_de_compte, valeur_initiale, taux):
        """Initialise une instance de la classe InterestAccount en héritant de la classe Account.

        Args:
            numero_de_compte (str): Le numéro de compte.
            type_de_compte (str): Le type de compte.
            valeur_initiale (float): La valeur initiale du solde du compte.
            taux (float): Le taux d'intérêt associé au compte.
        """
        super().__init__(numero_de_compte, type_de_compte, valeur_initiale)
        self.__rate = taux

    def ajouter_argent(self, somme):
        """Ajoute une somme d'argent au solde du compte d'intérêt en prenant en compte le taux d'intérêt.

        Args:
            somme (float): La somme d'argent à ajouter.
        """
        self._Account__account_balance = self._Account__account_balance + somme + (somme * (self.__rate / 100))

    def get_account_rate(self):
        """Renvoie le taux d'intérêt associé au compte.

        Returns:
            float: Le taux d'intérêt.
        """
        return self.__rate


