#Constantes du projet


# Définir le fichier de log des comptes
FILENAME_ACCOUNT = "logbook_count.csv"
# Définir le fichier de log des transactions
FILENAME_TRANSACTION = "log_banking_transaction.csv"